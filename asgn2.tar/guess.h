/*
 * Jacob Territo
 * Header for main guess function
 * asgn2
 */

#ifndef GUESS_H
#define GUESS_H
#include "treeFuncs.h"
#endif
