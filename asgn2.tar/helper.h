/*
 * Jacob Territo
 * Header for helper functions
 * asgn2
 */

#ifndef HELPER_H
#define MYTR_H
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
char * readLine(FILE *file);
int yesNo();
char * getLine(FILE* file);
#endif
